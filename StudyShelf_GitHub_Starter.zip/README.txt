# StudyShelf starter website

This is a starter front-end for StudyShelf. It is not a live store yet.

## Publish with GitHub Pages
1. Create a public GitHub repository named `studyshelf`.
2. Upload `index.html` to the repository root (the top level).
3. Open repository Settings → Pages.
4. Under Build and deployment, choose Deploy from a branch.
5. Select branch `main` and folder `/(root)`, then Save.
6. Wait for deployment and open the URL shown in Settings → Pages.

## Important
- The products and prices in this demo are examples.
- No payment processing is configured.
- No automatic PDF delivery is configured.
- Do not upload private customer information, passwords, API keys, or secret payment details.
- Only sell PDFs you created or have permission to distribute.
